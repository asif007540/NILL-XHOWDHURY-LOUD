// NILL Admin — edits license.json in your GitHub repo from your phone. No server of ours involved.
(() => {
  const $ = (id) => document.getElementById(id);
  const LS = (k, v) => { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (_) {} return null; };
  const cfg = () => { try { return JSON.parse(LS('nillAdminCfg') || '{}'); } catch (_) { return {}; } };
  const names = () => { try { return JSON.parse(LS('nillAdminNames') || '{}'); } catch (_) { return {}; } };
  const saveNames = (n) => LS('nillAdminNames', JSON.stringify(n));

  let state = { enabled: true, blocked: [], message: '' };
  let sha = null, busy = false;

  const b64enc = (s) => btoa(String.fromCharCode(...new TextEncoder().encode(s)));
  const b64dec = (s) => new TextDecoder().decode(Uint8Array.from(atob(s.replace(/\s/g, '')), (c) => c.charCodeAt(0)));
  const normId = (s) => String(s || '').trim().toUpperCase().replace(/\s+/g, '');

  function say(t, cls) { const s = $('status'); s.textContent = t || ''; s.className = cls || ''; }
  function api(c, method, body) {
    const path = String(c.file).split('/').map(encodeURIComponent).join('/');
    const url = `https://api.github.com/repos/${encodeURIComponent(c.user)}/${encodeURIComponent(c.repo)}/contents/${path}` + (method === 'GET' ? `?ref=${encodeURIComponent(c.branch)}&t=${Date.now()}` : '');
    return fetch(url, {
      method, cache: 'no-store',
      headers: { Accept: 'application/vnd.github+json', Authorization: 'Bearer ' + c.token, 'X-GitHub-Api-Version': '2022-11-28', ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined
    });
  }
  const ready = (c) => c.user && c.repo && c.file && c.branch && c.token;

  async function load() {
    const c = cfg(); if (!ready(c)) return false;
    say('লোড হচ্ছে…');
    try {
      const r = await api(c, 'GET');
      if (r.status === 404) { sha = null; state = { enabled: true, blocked: [], message: '' }; render(); say('ফাইল নেই — প্রথম সেভে তৈরি হবে', 'ok'); return true; }
      if (r.status === 401 || r.status === 403) throw new Error('Token ঠিক নেই বা অনুমতি নেই');
      if (!r.ok) throw new Error('GitHub error ' + r.status);
      const j = await r.json();
      sha = j.sha;
      const d = JSON.parse(b64dec(j.content));
      state = { enabled: d.enabled !== false, blocked: Array.isArray(d.blocked) ? d.blocked.map(normId) : [], message: String(d.message || '') };
      render(); say('আপডেট করা হয়েছে ✓', 'ok'); return true;
    } catch (e) { say(String(e.message || e), 'err'); return false; }
  }

  async function commit(note) {
    if (busy) return false;
    const c = cfg(); if (!ready(c)) { say('আগে সেটআপ করো', 'err'); return false; }
    busy = true; say('সেভ হচ্ছে…');
    const body = { enabled: state.enabled, blocked: state.blocked, message: state.message, updated: new Date().toISOString() };
    try {
      for (let attempt = 0; attempt < 2; attempt++) {
        const r = await api(c, 'PUT', { message: 'NILL admin: ' + (note || 'update'), content: b64enc(JSON.stringify(body, null, 2) + '\n'), branch: c.branch, ...(sha ? { sha } : {}) });
        if (r.status === 409 || r.status === 422) { // file changed elsewhere: refresh sha and retry once
          const g = await api(c, 'GET'); if (g.ok) { sha = (await g.json()).sha; continue; }
        }
        if (!r.ok) throw new Error(r.status === 401 || r.status === 403 ? 'Token-এ লেখার অনুমতি নেই' : 'সেভ হয়নি (' + r.status + ')');
        sha = (await r.json()).content.sha;
        say('সেভ হয়েছে ✓ — ২-৩ মিনিটে কার্যকর হবে', 'ok'); busy = false; return true;
      }
      throw new Error('সেভ হয়নি, আবার চেষ্টা করো');
    } catch (e) { say(String(e.message || e), 'err'); busy = false; await load(); return false; }
  }

  function render() {
    const mc = $('masterCard'); mc.classList.toggle('off', !state.enabled);
    $('mState').textContent = state.enabled ? 'চালু আছে' : 'বন্ধ';
    $('mHint').textContent = state.enabled ? 'সবার এক্সটেনশন চলছে (নিচে যাদের ব্লক করা আছে তারা বাদে)।' : 'সবার এক্সটেনশন বন্ধ হয়ে যাবে।';
    $('msg').value = state.message;
    const n = names();
    const ids = [...new Set([...Object.keys(n), ...state.blocked])];
    const ul = $('list'); ul.textContent = '';
    $('empty').hidden = ids.length > 0;
    for (const id of ids) {
      const blocked = state.blocked.includes(id);
      const li = document.createElement('li');
      const who = document.createElement('div'); who.className = 'who';
      const b = document.createElement('b'); b.textContent = n[id] || 'নামহীন';
      const pill = document.createElement('span'); pill.className = 'pill ' + (blocked ? 'off' : 'on'); pill.textContent = blocked ? 'বন্ধ' : 'চালু'; b.appendChild(pill);
      const code = document.createElement('code'); code.textContent = id;
      who.append(b, code);
      const sw = document.createElement('button'); sw.className = 'sw ' + (blocked ? 'allow' : 'block'); sw.textContent = blocked ? 'চালু করুন' : 'বন্ধ করুন';
      sw.onclick = async () => { const was = state.blocked.slice(); state.blocked = blocked ? was.filter((x) => x !== id) : [...was, id]; render(); if (!(await commit((blocked ? 'allow ' : 'block ') + id))) { /* load() inside commit restores */ } };
      const del = document.createElement('button'); del.className = 'del'; del.setAttribute('aria-label', 'Remove'); del.textContent = '🗑';
      del.onclick = async () => {
        if (!confirm((n[id] || id) + ' তালিকা থেকে মুছবে?' + (blocked ? '\n(ব্লক তালিকা থেকেও সরবে, অর্থাৎ আবার চালু হবে)' : ''))) return;
        const nn = names(); delete nn[id]; saveNames(nn);
        if (blocked) { state.blocked = state.blocked.filter((x) => x !== id); await commit('remove ' + id); } else render();
      };
      li.append(who, sw, del); ul.appendChild(li);
    }
  }

  function show() {
    const ok = ready(cfg());
    $('setup').hidden = ok && !showSetup; $('panel').hidden = !ok;
    if (!ok) $('setup').hidden = false;
  }
  let showSetup = false;

  $('gear').onclick = () => {
    showSetup = !showSetup; const c = cfg();
    $('fUser').value = c.user || ''; $('fRepo').value = c.repo || 'nill-switch'; $('fFile').value = c.file || 'license.json'; $('fBranch').value = c.branch || 'main'; $('fToken').value = c.token || '';
    show();
  };
  $('saveSetup').onclick = async () => {
    const c = { user: $('fUser').value.trim(), repo: $('fRepo').value.trim(), file: $('fFile').value.trim(), branch: $('fBranch').value.trim() || 'main', token: $('fToken').value.trim() };
    if (!ready(c)) { alert('সবগুলো ঘর পূরণ করো'); return; }
    LS('nillAdminCfg', JSON.stringify(c)); showSetup = false; show(); await load();
  };
  $('wipe').onclick = () => { if (confirm('এই ফোন থেকে সেটআপ ও Token মুছে ফেলবে?')) { LS('nillAdminCfg', '{}'); showSetup = false; show(); } };
  $('mToggle').onclick = async () => {
    const next = !state.enabled;
    if (!next && !confirm('সবার এক্সটেনশন বন্ধ করবে?')) return;
    state.enabled = next; render(); await commit(next ? 'enable all' : 'disable all');
  };
  $('saveMsg').onclick = async () => { state.message = $('msg').value.trim().slice(0, 120); await commit('message'); };
  $('dAdd').onclick = async () => {
    const id = normId($('dId').value), name = $('dName').value.trim();
    if (!/^[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(id)) { alert('ID ঠিক নেই। উদাহরণ: AB12-CD34'); return; }
    const n = names(); n[id] = name || 'নামহীন'; saveNames(n);
    $('dName').value = ''; $('dId').value = ''; render(); say('যোগ হয়েছে — এখন "বন্ধ করুন" চাপলে ব্লক হবে', 'ok');
  };
  $('reload').onclick = load;

  show(); if (ready(cfg())) load();
})();
