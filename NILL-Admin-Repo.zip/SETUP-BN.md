# NILL Admin — ফোন থেকে সেটআপ (একবারই, ~১০ মিনিট)

## ১) GitHub রিপোজিটরি
1. github.com এ অ্যাকাউন্ট খোলো (না থাকলে) এবং লগইন করো।
2. **New repository** → নাম দাও `nill-switch` → **Public** → Create।
3. **Add file → Upload files** চাপো। এই জিপ আনজিপ করে ভেতরের সব ফাইল (`index.html, app.js, style.css, sw.js, manifest.webmanifest, icon.svg, license.json`) আপলোড করো → **Commit changes**।

## ২) অ্যাডমিন অ্যাপের লিংক চালু করো
Repo → **Settings → Pages** → Branch: `main` / `(root)` → **Save**।
১-২ মিনিট পর লিংক আসবে: `https://তোমার-ইউজারনেম.github.io/nill-switch/`

## ৩) Token বানাও (শুধু এই repo-র জন্য)
GitHub → ছবি/মেনু → **Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token**
- Repository access: **Only select repositories** → `nill-switch`
- Permissions → **Contents: Read and write**
- Generate করে `github_pat_...` কপি করো।

## ৪) অ্যাপ চালু করো
১. ফোনের ব্রাউজারে ২ নম্বরের লিংক খোলো।
২. ইউজারনেম + Token বসিয়ে **সেভ ও সংযোগ** চাপো।
৩. ব্রাউজার মেনু → **Add to Home screen / হোম স্ক্রিনে যোগ করো** — অ্যাপের মতো খুলবে।

## ৫) এক্সটেনশনে যুক্ত করো
এক্সটেনশনের `license-config.js` ফাইলে `GITHUB_USER: ''` এর ভেতরে তোমার GitHub ইউজারনেম বসাও (অথবা ইউজারনেম আমাকে পাঠালে আমি বসিয়ে নতুন জিপ দেব), তারপর সেই কপি অন্যকে দাও।

## ব্যবহার
- বড় সুইচ = সবার এক্সটেনশন চালু/বন্ধ।
- ডিভাইস: ব্যবহারকারীর এক্সটেনশন পপআপের নিচের **License ID** নাম সহ যোগ করো → **বন্ধ করুন** চাপলে শুধু সে বন্ধ হবে।
- বন্ধ করার ২-৩ মিনিটের মধ্যে তাদের এক্সটেনশন বন্ধ হয়ে যায়।
- নামগুলো শুধু তোমার ফোনে থাকে, GitHub-এ যায় না (সেখানে শুধু ID থাকে)।
